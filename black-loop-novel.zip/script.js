fetch('episodes.json')
  .then(response => response.json())
  .then(data => {
    const container = document.getElementById('episodes');
    data.episodes.forEach((ep, index) => {
      const div = document.createElement('div');
      div.className = 'episode';
      div.innerHTML = `<h2>ตอนที่ ${index + 1}: ${ep.title}</h2>
        <div class="system">🎮 ระบบเกม: ${ep.system}</div>
        <p>${ep.content}</p>`;
      container.appendChild(div);
    });
  });