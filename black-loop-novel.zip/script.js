
let currentEpisode = 1;

async function loadEpisode(episodeNumber) {
    try {
        const response = await fetch('episodes.json');
        const data = await response.json();

        const episode = data.episodes.find(e => e.number === episodeNumber);
        if (!episode) return;

        const container = document.getElementById('episode-container');
        const div = document.createElement('div');
        div.className = 'episode';
        div.innerHTML = `<h2>${episode.title}</h2><pre>${episode.content}</pre>`;
        container.appendChild(div);
    } catch (error) {
        console.error('Error loading episode:', error);
    }
}

function handleScroll() {
    const scrollPosition = window.innerHeight + window.scrollY;
    const documentHeight = document.body.offsetHeight;

    if (scrollPosition >= documentHeight - 100) {
        currentEpisode++;
        loadEpisode(currentEpisode);
    }
}

window.addEventListener('DOMContentLoaded', () => {
    loadEpisode(currentEpisode);
    window.addEventListener('scroll', handleScroll);
});
